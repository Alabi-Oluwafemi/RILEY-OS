import { db } from '../src/lib/db';
import { hashPassword, passwordPolicy } from '../src/lib/security';

const email=(process.env.BOOTSTRAP_OWNER_EMAIL??'').trim().toLowerCase();
const password=process.env.BOOTSTRAP_OWNER_PASSWORD??'';
if(!email||!password) throw new Error('Set BOOTSTRAP_OWNER_EMAIL and BOOTSTRAP_OWNER_PASSWORD before npm run db:seed.');
const policy=passwordPolicy(password); if(policy) throw new Error(policy);
const exists=db.prepare('SELECT id FROM users WHERE email=?').get(email) as {id:number}|undefined;
if(!exists){ const r=db.prepare(`INSERT INTO users (email,name,role,password_hash,must_change_password,is_active) VALUES (?,?,?,?,0,1)`).run(email,'Riley’s Owner','OWNER',hashPassword(password)); console.log(`Created owner user ${r.lastInsertRowid}: ${email}`); }
else console.log(`Owner already exists: ${email}`);
console.log('Create employees/developers/security analysts/customers through the Team screen using least privilege.');
