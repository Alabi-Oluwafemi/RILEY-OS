import type {Metadata} from 'next'; import './globals.css'; import AppShell from '@/components/AppShell';
export const metadata:Metadata={title:"Riley's Digest — Secure Business Hub",description:'Least-privilege business operations platform for Riley’s Digest.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><AppShell>{children}</AppShell></body></html>}
