'use client';
import { useEffect, useState } from 'react';
import Topbar from '@/components/Topbar';
import DataTable from '@/components/DataTable';
import StatusPill from '@/components/StatusPill';
import { request } from '@/lib/api';
type Client = {id:number;name:string;email?:string;phone?:string;company?:string;status:string};
export default function ClientsPage(){
 const [items,setItems]=useState<Client[]>([]); const [open,setOpen]=useState(false); const [form,setForm]=useState({name:'',email:'',phone:'',company:'',status:'active'}); const [error,setError]=useState('');
 async function load(){setItems(await request<Client[]>('/api/clients'));}
 useEffect(()=>{load()},[]);
 async function submit(e:React.FormEvent){e.preventDefault();setError('');try{await request('/api/clients',{method:'POST',body:JSON.stringify(form)});setOpen(false);setForm({name:'',email:'',phone:'',company:'',status:'active'});load();}catch(err){setError(err instanceof Error?err.message:'Could not save');}}
 return <><Topbar title="Clients" subtitle="Manage client relationships and service history." />
 <div className="page-tools"><button className="button primary" onClick={()=>setOpen(true)}>+ Add client</button><span className="muted">{items.length} records</span></div>
 <section className="panel"><DataTable headers={['Client','Company','Contact','Status']} rows={items.map(c=>[<strong key="n">{c.name}</strong>,c.company||'—',<span key="e">{c.email||c.phone||'—'}</span>,<StatusPill key="s" tone={c.status==='active'?'success':c.status==='lead'?'info':'neutral'}>{c.status}</StatusPill>])}/></section>
 {open && <div className="modal-backdrop"><form className="modal" onSubmit={submit}><div className="modal-head"><h2>New client</h2><button type="button" className="icon-button" onClick={()=>setOpen(false)}>×</button></div><div className="form-grid"><label>Name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>Company<input value={form.company} onChange={e=>setForm({...form,company:e.target.value})}/></label><label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label>Status<select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}><option>active</option><option>prospect</option><option>lead</option><option>inactive</option></select></label></div>{error&&<p className="error">{error}</p>}<div className="modal-actions"><button type="button" className="button" onClick={()=>setOpen(false)}>Cancel</button><button className="button primary">Save client</button></div></form></div>}
 </>;
}
