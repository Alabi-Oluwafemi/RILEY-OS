import { NextResponse } from 'next/server';
import { csrfCookieValue, ensureCsrfCookieValue, setCsrfCookie } from '@/lib/security';
export async function GET(){ const value=ensureCsrfCookieValue(await csrfCookieValue()); await setCsrfCookie(value); return NextResponse.json({ok:true}); }
