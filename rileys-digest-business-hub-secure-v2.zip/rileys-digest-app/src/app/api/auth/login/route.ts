import { NextResponse } from 'next/server';
import { db } from '@/lib/db'; import { createSession, setSessionCookie, verifyPassword, rateLimit, clientIp, passwordPolicy, readCsrfHeader, sameOrigin } from '@/lib/security'; import { writeAudit } from '@/lib/auth';
export async function POST(request:Request){
  if(!sameOrigin(request) || !(await readCsrfHeader(request))) return NextResponse.json({error:'Request rejected'}, {status:403});
  const ip=clientIp(request); const rl=rateLimit(`login:${ip}`,10,15*60_000); if(!rl.ok) return NextResponse.json({error:'Too many login attempts. Try again later.'},{status:429,headers:{'Retry-After':String(rl.retryAfter)}});
  const body=await request.json().catch(()=>null); const email=typeof body?.email==='string'?body.email.trim().toLowerCase():''; const password=typeof body?.password==='string'?body.password:'';
  if(!email||!password||password.length>256) return NextResponse.json({error:'Email and password are required.'},{status:400});
  const user=db.prepare('SELECT id,email,name,role,client_id,is_active,must_change_password,password_hash FROM users WHERE email=? LIMIT 1').get(email) as any;
  if(!user || !user.is_active || !verifyPassword(password,user.password_hash)){ await writeAudit(null,request,'auth.login_failed','user',null,{email}); return NextResponse.json({error:'Invalid email or password.'},{status:401}); }
  const policy=passwordPolicy(password); if(policy) return NextResponse.json({error:policy},{status:400});
  const {token,expires}=createSession(user.id,request); await setSessionCookie(token,expires); db.prepare('UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?').run(user.id);
  await writeAudit({...user,password_hash:undefined},request,'auth.login','user',user.id,{role:user.role});
  return NextResponse.json({user:{id:user.id,email:user.email,name:user.name,role:user.role,must_change_password:user.must_change_password}});
}
