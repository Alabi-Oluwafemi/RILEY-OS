import {NextResponse} from 'next/server'; import {getCurrentUser} from '@/lib/auth'; import {ROLE_PERMISSIONS} from '@/lib/permissions';
export async function GET(request:Request){const user=await getCurrentUser(request);if(!user)return NextResponse.json({error:'Authentication required'},{status:401});return NextResponse.json({user,permissions:ROLE_PERMISSIONS[user.role]});}
