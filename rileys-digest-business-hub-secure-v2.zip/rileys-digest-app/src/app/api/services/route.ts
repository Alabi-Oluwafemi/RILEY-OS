import {NextResponse} from 'next/server'; import {db} from '@/lib/db'; import {requirePermission} from '@/lib/auth';
export async function GET(req:Request){const g=await requirePermission(req,'services:read');if(!g.ok)return g.response;return NextResponse.json(db.prepare('SELECT id,name,category,description,price,active FROM services WHERE active=1 ORDER BY category,name').all());}
