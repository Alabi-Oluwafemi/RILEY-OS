import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import { db } from './db';

const SESSION_COOKIE = 'rd_session';
const CSRF_COOKIE = 'rd_csrf';
const SESSION_TTL_MS = Math.max(1, Number(process.env.SESSION_TTL_HOURS ?? 8)) * 60 * 60 * 1000;

export function clientIp(request: Request) {
  if (process.env.TRUST_PROXY === 'true') {
    const forwarded = request.headers.get('x-forwarded-for');
    if (forwarded) return forwarded.split(',')[0].trim().slice(0, 64);
    const real = request.headers.get('x-real-ip');
    if (real) return real.slice(0, 64);
  }
  return 'unknown';
}

export function hashPassword(password: string, salt = crypto.randomBytes(16).toString('hex')) {
  const derived = crypto.scryptSync(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });
  return `${salt}:${derived.toString('hex')}`;
}

export function verifyPassword(password: string, encoded: string) {
  const [salt, expected] = encoded.split(':');
  if (!salt || !expected) return false;
  const actual = crypto.scryptSync(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 }).toString('hex');
  const a = Buffer.from(actual, 'hex');
  const b = Buffer.from(expected, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function passwordPolicy(password: unknown) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 256) return 'Password must be 12–256 characters.';
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) return 'Password must contain letters and numbers.';
  return null;
}

export function tokenHash(token: string) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function createSession(userId: number, request: Request) {
  const token = crypto.randomBytes(32).toString('base64url');
  const tokenHashValue = tokenHash(token);
  const expires = new Date(Date.now() + SESSION_TTL_MS).toISOString();
  db.prepare(`INSERT INTO sessions (token_hash,user_id,expires_at,ip,user_agent) VALUES (?,?,?,?,?)`)
    .run(tokenHashValue, userId, expires, clientIp(request), request.headers.get('user-agent')?.slice(0, 300) ?? null);
  return { token, expires };
}

export async function setSessionCookie(token: string, expires: string) {
  const store = await cookies();
  store.set({ name: SESSION_COOKIE, value: token, httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', expires: new Date(expires) });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.set({ name: SESSION_COOKIE, value: '', httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 0 });
}

export async function getSessionToken() {
  return (await cookies()).get(SESSION_COOKIE)?.value ?? null;
}

export function ensureCsrfCookieValue(current?: string) {
  return current && /^[A-Za-z0-9_-]{32,128}$/.test(current) ? current : crypto.randomBytes(32).toString('base64url');
}

export async function setCsrfCookie(value: string) {
  const store = await cookies();
  store.set({ name: CSRF_COOKIE, value, httpOnly: false, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 86400 });
}

export async function csrfCookieValue() {
  return (await cookies()).get(CSRF_COOKIE)?.value ?? null;
}

export function sameOrigin(request: Request) {
  const method = request.method.toUpperCase();
  if (['GET','HEAD','OPTIONS'].includes(method)) return true;
  const origin = request.headers.get('origin');
  if (!origin) return true;
  const allowed = (process.env.APP_ALLOWED_ORIGINS ?? '').split(',').map((v) => v.trim()).filter(Boolean);
  const host = request.headers.get('host');
  if (host && origin === `http${process.env.NODE_ENV === 'production' ? 's' : ''}://${host}`) return true;
  return allowed.includes(origin);
}

const buckets = new Map<string, { count: number; resetAt: number }>();
export function rateLimit(key: string, limit: number, windowMs: number) {
  if (buckets.size > 10000) { for (const [k,v] of buckets) if (v.resetAt <= Date.now()) buckets.delete(k); }
  const now = Date.now();
  const existing = buckets.get(key);
  if (!existing || existing.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, retryAfter: 0 };
  }
  existing.count += 1;
  return { ok: existing.count <= limit, retryAfter: Math.ceil((existing.resetAt - now) / 1000) };
}

export async function readCsrfHeader(request: Request) {
  const header = request.headers.get('x-rd-csrf');
  const cookie = await csrfCookieValue();
  if (!header || !cookie || header.length !== cookie.length) return false;
  return crypto.timingSafeEqual(Buffer.from(header), Buffer.from(cookie));
}
