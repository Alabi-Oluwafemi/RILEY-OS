import { NextResponse } from 'next/server';
import { db } from './db';
import { Permission, Role, hasPermission } from './permissions';
import { clientIp, getSessionToken, readCsrfHeader, rateLimit, sameOrigin, tokenHash } from './security';

export type CurrentUser = { id:number; email:string; name:string; role:Role; client_id:number|null; is_active:number; must_change_password:number };

export async function getCurrentUser(request?: Request): Promise<CurrentUser|null> {
  db.prepare("DELETE FROM sessions WHERE expires_at <= CURRENT_TIMESTAMP").run();
  const token = request ? (request.headers.get('cookie')?.match(/(?:^|;\s*)rd_session=([^;]+)/)?.[1] ?? null) : await getSessionToken();
  if (!token) return null;
  const row = db.prepare(`SELECT u.id,u.email,u.name,u.role,u.client_id,u.is_active,u.must_change_password,s.id session_id,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? LIMIT 1`).get(tokenHash(token)) as (CurrentUser & {session_id:number;expires_at:string})|undefined;
  if (!row || !row.is_active || new Date(row.expires_at).getTime() <= Date.now()) return null;
  db.prepare('UPDATE sessions SET last_seen_at=CURRENT_TIMESTAMP WHERE id=?').run(row.session_id);
  return row;
}

export async function requirePermission(request: Request, permission: Permission) {
  const user = await getCurrentUser(request);
  if (!user) return { ok:false as const, response: NextResponse.json({error:'Authentication required'}, {status:401}) };
  const limited = rateLimit(`api:${user.id}:${permission}`, 120, 60_000);
  if (!limited.ok) return { ok:false as const, response: NextResponse.json({error:'Rate limit exceeded'}, {status:429,headers:{'Retry-After':String(limited.retryAfter)}}) };
  if (!hasPermission(user.role, permission)) {
    await writeAudit(user, request, 'authz.denied', permission, null, { role:user.role });
    return { ok:false as const, response: NextResponse.json({error:'Forbidden'}, {status:403}) };
  }
  if (!sameOrigin(request)) return { ok:false as const, response: NextResponse.json({error:'Origin rejected'}, {status:403}) };
  if (!['GET','HEAD','OPTIONS'].includes(request.method.toUpperCase())) {
    const contentLength=Number(request.headers.get('content-length')??0);
    if (contentLength > 100_000) return { ok:false as const, response: NextResponse.json({error:'Request body too large'}, {status:413}) };
    if (!(await readCsrfHeader(request))) return { ok:false as const, response: NextResponse.json({error:'CSRF validation failed'}, {status:403}) };
  }
  return { ok:true as const, user };
}

export async function writeAudit(user: CurrentUser|null, request: Request, action: string, resource: string, resourceId: string|number|null, metadata?: Record<string,unknown>) {
  db.prepare('INSERT INTO audit_logs (user_id,action,resource,resource_id,metadata,ip,user_agent) VALUES (?,?,?,?,?,?,?)').run(
    user?.id ?? null, action, resource, resourceId == null ? null : String(resourceId), metadata ? JSON.stringify(metadata).slice(0,4000) : null,
    clientIp(request), request.headers.get('user-agent')?.slice(0,300) ?? null
  );
}
