import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';

const dbPath = process.env.DATABASE_PATH ? path.resolve(process.env.DATABASE_PATH) : path.join(process.cwd(), 'data', 'rileys.db');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const globalForDb = globalThis as unknown as { __rileysDb?: Database.Database };
export const db = globalForDb.__rileysDb ?? new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');
db.pragma('secure_delete = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 name TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('OWNER','EMPLOYEE','DEVELOPER','SECURITY_ANALYST','CUSTOMER')),
 password_hash TEXT NOT NULL,
 client_id INTEGER,
 is_active INTEGER NOT NULL DEFAULT 1,
 must_change_password INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 last_login_at TEXT,
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS sessions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 token_hash TEXT NOT NULL UNIQUE,
 user_id INTEGER NOT NULL,
 expires_at TEXT NOT NULL,
 ip TEXT,
 user_agent TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS audit_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 action TEXT NOT NULL,
 resource TEXT NOT NULL,
 resource_id TEXT,
 metadata TEXT,
 ip TEXT,
 user_agent TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE TABLE IF NOT EXISTS clients (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT,
 phone TEXT,
 company TEXT,
 status TEXT NOT NULL DEFAULT 'lead',
 notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 category TEXT NOT NULL,
 description TEXT,
 price REAL NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS projects (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 client_id INTEGER,
 service_id INTEGER,
 title TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open',
 priority TEXT NOT NULL DEFAULT 'normal',
 due_date TEXT,
 budget REAL NOT NULL DEFAULT 0,
 notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
 FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS tasks (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 project_id INTEGER,
 assigned_to INTEGER,
 title TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'todo',
 due_date TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
 FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 sku TEXT UNIQUE,
 name TEXT NOT NULL,
 category TEXT,
 quantity REAL NOT NULL DEFAULT 0,
 reorder_level REAL NOT NULL DEFAULT 5,
 buy_price REAL NOT NULL DEFAULT 0,
 sell_price REAL NOT NULL DEFAULT 0,
 supplier TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS stock_movements (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER NOT NULL,
 user_id INTEGER,
 type TEXT NOT NULL CHECK(type IN ('in','out','adjustment')),
 quantity REAL NOT NULL,
 reference TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS content (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 category TEXT NOT NULL,
 excerpt TEXT,
 body TEXT,
 status TEXT NOT NULL DEFAULT 'draft',
 author_id INTEGER,
 published_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS social_posts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 content_id INTEGER,
 created_by INTEGER,
 platform TEXT NOT NULL,
 caption TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'draft',
 scheduled_for TEXT,
 published_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (content_id) REFERENCES content(id) ON DELETE SET NULL,
 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS invoices (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 client_id INTEGER,
 invoice_number TEXT NOT NULL UNIQUE,
 status TEXT NOT NULL DEFAULT 'unpaid',
 subtotal REAL NOT NULL DEFAULT 0,
 tax REAL NOT NULL DEFAULT 0,
 total REAL NOT NULL DEFAULT 0,
 due_date TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS invoice_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 invoice_id INTEGER NOT NULL,
 description TEXT NOT NULL,
 quantity REAL NOT NULL DEFAULT 1,
 unit_price REAL NOT NULL DEFAULT 0,
 line_total REAL NOT NULL DEFAULT 0,
 FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS leads (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT,
 phone TEXT,
 source TEXT,
 service_interest TEXT,
 stage TEXT NOT NULL DEFAULT 'new',
 notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS service_requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 client_id INTEGER NOT NULL,
 service_id INTEGER,
 title TEXT NOT NULL,
 description TEXT,
 status TEXT NOT NULL DEFAULT 'submitted',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
 FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
);
`);

// Backward-compatible schema upgrades from v1.
for (const stmt of [
  `ALTER TABLE users ADD COLUMN client_id INTEGER`,
  `ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 1`,
  `ALTER TABLE tasks ADD COLUMN assigned_to INTEGER`,
  `ALTER TABLE stock_movements ADD COLUMN user_id INTEGER`,
  `ALTER TABLE content ADD COLUMN author_id INTEGER`,
  `ALTER TABLE social_posts ADD COLUMN created_by INTEGER`,
]) { try { db.exec(stmt); } catch {} }
if (!globalForDb.__rileysDb) globalForDb.__rileysDb = db;

export function seedDatabase() {
  const servicesCount = (db.prepare('SELECT COUNT(*) count FROM services').get() as {count:number}).count;
  const clientCount = (db.prepare('SELECT COUNT(*) count FROM clients').get() as {count:number}).count;
  if (!servicesCount) {
    const ins = db.prepare('INSERT INTO services (name,category,description,price) VALUES (?,?,?,?)');
    [
      ['Life Coaching','Coaching','Goal setting, accountability and personal growth coaching.',50000],
      ['Blogging & Content','Content','Research, articles, copy and thought-leadership content.',35000],
      ['Cybersecurity Services','Technology','Authorized defensive reviews, hygiene and awareness.',100000],
      ['Data Entry','Operations','Accurate data capture, cleanup and spreadsheet management.',25000],
      ['Inventory Management','Operations','Stock tracking, reorder alerts and inventory reporting.',60000],
      ['Social Media Management','Marketing','Planning, scheduling, publishing and reporting.',75000],
      ['General Goods','Commerce','Sale and fulfillment of selected general goods.',0]
    ].forEach((r) => ins.run(...r));
  }
  if (!clientCount) {
    const ins = db.prepare('INSERT INTO clients (name,email,phone,company,status) VALUES (?,?,?,?,?)');
    ins.run('Ayo Ventures','hello@ayoventures.example','+234 800 000 0001','Ayo Ventures','active');
    ins.run('Faith & Purpose Hub','team@faithpurpose.example','+234 800 000 0002','Faith & Purpose Hub','active');
    ins.run('Northside Retail','ops@northside.example','+234 800 000 0003','Northside Retail','prospect');
  }
  if (!(db.prepare('SELECT COUNT(*) count FROM products').get() as {count:number}).count) {
    const ins = db.prepare('INSERT INTO products (sku,name,category,quantity,reorder_level,buy_price,sell_price,supplier) VALUES (?,?,?,?,?,?,?,?)');
    ins.run('RD-001','Notebook Journal','Stationery',42,10,2500,4500,'Local Supplier');
    ins.run('RD-002','USB Flash Drive 64GB','Electronics',9,12,9000,14500,'Tech Supplier');
    ins.run('RD-003','Desk Planner','Stationery',28,8,3000,5500,'Local Supplier');
    ins.run('RD-004','Phone Stand','Accessories',3,5,3500,7000,'Tech Supplier');
  }
  if (!(db.prepare('SELECT COUNT(*) count FROM content').get() as {count:number}).count) {
    const ins = db.prepare('INSERT INTO content (title,category,excerpt,body,status,published_at) VALUES (?,?,?,?,?,?)');
    ins.run('Wisdom, Discipline & Daily Practice','Bible','Biblical wisdom for disciplined habits.','Draft body for the first Riley’s Digest article.','published',new Date().toISOString());
    ins.run('What Makes an Idea Worth Believing?','Philosophy','A critical-thinking framework.','Draft body.','draft',null);
    ins.run('Practical Cyber Hygiene for Small Businesses','Cybersecurity','Simple security controls.','Draft body.','draft',null);
    ins.run('AI Tools That Save Time for Busy Teams','AI','Practical AI workflows.','Draft body.','draft',null);
    ins.run('Arsenal Match Notes & Tactical Themes','Arsenal','Matchday analysis template.','Draft body.','scheduled',new Date(Date.now()+86400000).toISOString());
  }
  if (!(db.prepare('SELECT COUNT(*) count FROM projects').get() as {count:number}).count) {
    const ins = db.prepare('INSERT INTO projects (client_id,service_id,title,status,priority,due_date,budget,notes) VALUES (?,?,?,?,?,?,?,?)');
    ins.run(1,2,'Monthly thought-leadership blog package','in_progress','normal',new Date(Date.now()+4*86400000).toISOString().slice(0,10),140000,'4 long-form posts plus social excerpts.');
    ins.run(2,1,'Four-session growth coaching programme','open','high',new Date(Date.now()+9*86400000).toISOString().slice(0,10),200000,'Goal setting and accountability.');
    ins.run(2,3,'Small business cyber hygiene review','open','normal',new Date(Date.now()+14*86400000).toISOString().slice(0,10),180000,'Authorized review and action plan.');
  }
  if (!(db.prepare('SELECT COUNT(*) count FROM leads').get() as {count:number}).count) {
    const ins = db.prepare('INSERT INTO leads (name,email,phone,source,service_interest,stage) VALUES (?,?,?,?,?,?)');
    ins.run('Emeka Okafor','emeka@example.com','+234 800 000 0004','Instagram','Social Media Management','qualified');
    ins.run('Grace Williams','grace@example.com','+234 800 000 0005','Referral','Life Coaching','new');
  }
  if (!(db.prepare('SELECT COUNT(*) count FROM invoices').get() as {count:number}).count) {
    const inv = Number(db.prepare('INSERT INTO invoices (client_id,invoice_number,status,subtotal,tax,total,due_date) VALUES (?,?,?,?,?,?,?)').run(1,'RD-INV-0001','paid',140000,0,140000,new Date(Date.now()+30*86400000).toISOString().slice(0,10)).lastInsertRowid);
    db.prepare('INSERT INTO invoice_items (invoice_id,description,quantity,unit_price,line_total) VALUES (?,?,?,?,?)').run(inv,'Monthly thought-leadership blog package',1,140000,140000);
  }
}
seedDatabase();
