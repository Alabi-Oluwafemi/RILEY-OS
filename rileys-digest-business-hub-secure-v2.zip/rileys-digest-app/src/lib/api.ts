export async function request<T>(url:string, options?:RequestInit):Promise<T>{
  const method=(options?.method ?? 'GET').toUpperCase();
  const headers=new Headers(options?.headers); headers.set('Content-Type','application/json');
  if(!['GET','HEAD','OPTIONS'].includes(method)){
    const existing=document.cookie.split('; ').find((v)=>v.startsWith('rd_csrf='));
    if(!existing) await fetch('/api/auth/csrf',{cache:'no-store'});
    const token=document.cookie.split('; ').find((v)=>v.startsWith('rd_csrf='))?.split('=').slice(1).join('=');
    if(token) headers.set('x-rd-csrf',token);
  }
  const response=await fetch(url,{...options,headers,credentials:'same-origin',cache:'no-store'});
  const data=await response.json().catch(()=>({}));
  if(response.status===401){ window.location.href='/login'; throw new Error('Authentication required'); }
  if(!response.ok) throw new Error(data.error ?? 'Request failed');
  return data;
}
export const money=(value:number)=>new Intl.NumberFormat('en-NG',{style:'currency',currency:'NGN',maximumFractionDigits:0}).format(value);
