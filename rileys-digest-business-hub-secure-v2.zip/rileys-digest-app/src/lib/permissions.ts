export type Role = 'OWNER' | 'EMPLOYEE' | 'DEVELOPER' | 'SECURITY_ANALYST' | 'CUSTOMER';

export type Permission =
  | 'dashboard:view'
  | 'clients:read' | 'clients:create' | 'clients:update'
  | 'leads:read' | 'leads:create' | 'leads:update'
  | 'projects:read' | 'projects:create' | 'projects:update'
  | 'tasks:read' | 'tasks:create' | 'tasks:update'
  | 'content:read' | 'content:create' | 'content:update' | 'content:publish'
  | 'social:read' | 'social:create' | 'social:update' | 'social:publish'
  | 'inventory:read' | 'inventory:create' | 'inventory:stock_in' | 'inventory:stock_out'
  | 'invoices:read' | 'invoices:create' | 'invoices:update' | 'invoices:mark_paid'
  | 'services:read' | 'services:manage'
  | 'security:read' | 'security:manage'
  | 'audit:read'
  | 'users:read' | 'users:manage'
  | 'settings:manage'
  | 'self:read' | 'self:update'
  | 'requests:read' | 'requests:create' | 'requests:update';

const all: Permission[] = [
  'dashboard:view','clients:read','clients:create','clients:update','leads:read','leads:create','leads:update',
  'projects:read','projects:create','projects:update','tasks:read','tasks:create','tasks:update',
  'content:read','content:create','content:update','content:publish','social:read','social:create','social:update','social:publish',
  'inventory:read','inventory:create','inventory:stock_in','inventory:stock_out','invoices:read','invoices:create','invoices:update','invoices:mark_paid',
  'services:read','services:manage','security:read','security:manage','audit:read','users:read','users:manage','settings:manage',
  'self:read','self:update','requests:read','requests:create','requests:update'
];

export const ROLE_PERMISSIONS: Record<Role, readonly Permission[]> = {
  OWNER: all,
  EMPLOYEE: [
    'dashboard:view','clients:read','clients:create','clients:update','leads:read','leads:create','leads:update',
    'projects:read','projects:create','projects:update','tasks:read','tasks:create','tasks:update',
    'content:read','content:create','content:update','social:read','social:create','social:update',
    'inventory:read','services:read','requests:read','requests:update','self:read','self:update'
  ],
  DEVELOPER: [
    'dashboard:view','services:read','security:read','audit:read','self:read','self:update'
  ],
  SECURITY_ANALYST: [
    'dashboard:view','security:read','security:manage','audit:read','self:read','self:update'
  ],
  CUSTOMER: [
    'dashboard:view','services:read','self:read','self:update','requests:read','requests:create','projects:read','invoices:read'
  ],
};

export function hasPermission(role: Role, permission: Permission) {
  return ROLE_PERMISSIONS[role].includes(permission);
}

export function hasAnyPermission(role: Role, permissions: Permission[]) {
  return permissions.some((p) => hasPermission(role, p));
}

export const ROLE_LABELS: Record<Role, string> = {
  OWNER: 'Owner / Administrator',
  EMPLOYEE: 'Employee / Operations',
  DEVELOPER: 'Developer',
  SECURITY_ANALYST: 'Security Analyst',
  CUSTOMER: 'Customer',
};
