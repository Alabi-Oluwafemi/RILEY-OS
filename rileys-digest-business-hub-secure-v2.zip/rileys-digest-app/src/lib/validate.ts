export function text(value: unknown, field: string, max=500) {
  if (value == null) return null;
  if (typeof value !== 'string') throw new Error(`${field} must be text.`);
  const v=value.trim(); if (v.length>max) throw new Error(`${field} is too long.`); return v || null;
}
export function requiredText(value: unknown, field: string, max=500) {
  const v=text(value, field, max); if (!v) throw new Error(`${field} is required.`); return v;
}
export function email(value: unknown) { const v=text(value,'Email',200); if (v && !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(v)) throw new Error('Email is invalid.'); return v; }
export function integerId(value: unknown, field='id') { const n=Number(value); if (!Number.isInteger(n)||n<=0) throw new Error(`${field} is invalid.`); return n; }
export function money(value: unknown, field='amount') { const n=Number(value); if (!Number.isFinite(n)||n<0||n>1e9) throw new Error(`${field} is invalid.`); return n; }
