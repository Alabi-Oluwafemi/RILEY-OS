export default function MetricCard({ label, value, hint }: { label: string; value: string; hint: string }) {
  return <section className="metric-card"><div className="eyebrow">{label}</div><div className="metric-value">{value}</div><div className="metric-hint">{hint}</div></section>;
}
