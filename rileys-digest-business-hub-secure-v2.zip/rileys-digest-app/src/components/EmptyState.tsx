export default function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty"><div className="empty-icon">◌</div><h3>{title}</h3><p>{text}</p></div>;
}
