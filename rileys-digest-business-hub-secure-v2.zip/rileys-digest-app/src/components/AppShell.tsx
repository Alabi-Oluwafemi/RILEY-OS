"use client";
import {usePathname} from 'next/navigation'; import Sidebar from './Sidebar'; import AuthGate from './AuthGate';
export default function AppShell({children}:{children:React.ReactNode}){const path=usePathname();if(path==='/login')return <>{children}</>;return <AuthGate><div className="app-shell"><Sidebar/><main className="main-content">{children}</main></div></AuthGate>}
