export default function StatusPill({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: 'neutral'|'success'|'warning'|'danger'|'info' }) {
  return <span className={`pill ${tone}`}>{children}</span>;
}
